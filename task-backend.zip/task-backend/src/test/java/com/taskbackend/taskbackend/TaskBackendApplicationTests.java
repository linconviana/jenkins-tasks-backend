package com.taskbackend.taskbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
